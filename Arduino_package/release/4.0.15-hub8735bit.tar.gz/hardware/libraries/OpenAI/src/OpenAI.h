/**
  * @Date: 2025/03/11
  * @Creator: Bob_Su
  */
#ifndef __OPENAI_H__
#define __OPENAI_H__

#include "Arduino.h"
#include "AmebaFatFS.h"

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus
#include "wsOpenAI_Block.h"
#ifdef __cplusplus
}
#endif //__cplusplus

class OpenAI {
private:
  static File *tts_file;
  static File *stt_file;
  static void textToSpeechGetDataCallback(unsigned char status, unsigned char *data, unsigned long size);
  static void speechToTextReadDataCallback(unsigned char *data, unsigned long *size);
  
public:
  OpenAI();
  void begin(char *api_key);
  /**
   * @brief Add system prompt
   * @param *prompt: System prompt
   * @retval Result
   */
  unsigned short chatAddSystemPrompt(char *prompt);
  /**
   * @brief Add new user message
   * @param *message: New user message
   * @retval Result
   */
  unsigned short  chatAddUserMessage(char *message);
  /**
   * @brief Clear all user messages
   * @param None
   * @retval None
   */
  void chatClearUserMessage(void);
  /**
   * @brief Start chat generation
   * @param None
   * @retval Chat genertaion string
   */
char* chatCompletion(void);
  /**
   * @brief Convert text to speech
   * @param &file: Speech file
   * @param *text: Input text
   * @retval Result
   */
  unsigned short textToSpeech(File &file, char *text);
  /**
   * @brief Convert text to speech
   * @param &file: Speech file
   * @param voice: Speech voice
   * @param *text: Input text
   * @retval Result
   */
  unsigned short textToSpeech(File &file, OpenAITTSVoice_Typedef voice, char *text);
  /**
   * @brief Convert speech to text
   * @param &file: Speech file
   * @retval Text
   */
  char *speechToText(File &file);
};

#endif //__OPENAI_H__