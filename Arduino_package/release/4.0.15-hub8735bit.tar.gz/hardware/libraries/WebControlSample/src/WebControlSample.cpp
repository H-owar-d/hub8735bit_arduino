#include <FreeRTOS.h>
#include <task.h>
#include <WiFi.h>
#include <platform_stdlib.h>
#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include "VideoStream.h"
#include "WebControlSample.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "video_drv.h"
#include "isp_ctrl_api.h"

#include <httpd/httpd.h>
#ifdef __cplusplus
}
#endif

#define LED_PIN LED_B
#define CHANNEL 0

extern IPAddress ipaddr;

void homepage_cb(struct httpd_conn *conn)
{
	char *user_agent = NULL;

	// test log to show brief header parsing
	httpd_conn_dump_header(conn);
  
  printf("ipaddr[0]=[%d]\n", ipaddr[0]);

	// test log to show extra User-Agent header field
	if (httpd_request_get_header_field(conn, "User-Agent", &user_agent) != -1) {
		printf("\nUser-Agent=[%s]\n", user_agent);
		httpd_free(user_agent);
	}

	// GET homepage
	if (httpd_request_is_method(conn, "GET")) {
    char body[1024];
    char ipstring[16];
    sprintf(ipstring, "%d.%d.%d.%d",ipaddr[0],ipaddr[1],ipaddr[2],ipaddr[3]);
    sprintf(body,
					 "<HTML>"
           "<script>var xhttp = new XMLHttpRequest();</script>"
           "<script>function getsend(arg) { xhttp.open('GET', arg +'?' + new Date().getTime(), true); xhttp.send() } </script>"
           "<BODY>"
           "<p align=center><IMG SRC='http://%s/Streaming' style='width:1920px height:1080px;'></p><br/><br/>"
           "<button style=background-color:yellow;width:140px;height:40px; onmousedown=getsend('ledon') ontouchstart=getsend('ledon') ><b>LED-On</b></button>"
           "<button style=background-color:yellow;width:140px;height:40px; onmousedown=getsend('ledoff') ontouchstart=getsend('ledoff') ><b>LED-Off</b></button>"
           "<p>Producer:Howard Tien</p>"
           "<p>2024</p>"
           "</div>"
					 "</BODY></HTML>",ipstring);
          // write HTTP response
          httpd_response_write_header_start(conn, "200 OK", "text/html", strlen(body));
          httpd_response_write_header(conn, "Connection", "close");
          httpd_response_write_header_finish(conn);
          httpd_response_write_data(conn, (uint8_t *)body, strlen(body));
	} else {
		// HTTP/1.1 405 Method Not Allowed
		httpd_response_method_not_allowed(conn, NULL);
	}

	httpd_conn_close(conn);
}

static void streaming_httpd_thread(void *param)
{
    char *user_agent = NULL;
    httpd_conn *conn = (httpd_conn *)param;
    
    printf("Streaming_cb\r\n");

    httpd_conn_dump_header(conn);

    // test log to show extra User-Agent header field
    if (httpd_request_get_header_field(conn, "User-Agent", &user_agent) != -1) {
      printf("\nUser-Agent=[%s]\n", user_agent);
      httpd_free(user_agent);
    }

    if (httpd_request_is_method(conn, "GET")) {
      char *header = "multipart/x-mixed-replace; boundary=123456789000000000000987654321";//" PART_BOUNDARY_THD "\r\nTransfer-Encoding: chunked\r\n\r\n";
  
      // write HTTP response
      httpd_response_write_header_start(conn, "200 OK", header, 0);
      httpd_response_write_header(conn, "Transfer-Encoding:", "chunked");
      httpd_response_write_header_finish(conn);
      while(conn)
      {
          Camera.getImage(CHANNEL, &img_addr_THD, &img_len_THD);
          uint8_t chunk_buf[64] = {0};
          uint8_t chunk_len = snprintf((char*)chunk_buf, 64, IMG_HEADER_THD, img_len_THD);
          httpd_response_write_data(conn, (uint8_t *)chunk_buf, chunk_len);
          httpd_response_write_data(conn, (uint8_t *)img_addr_THD, img_len_THD);
          httpd_response_write_data(conn, (uint8_t *)STREAM_BOUNDARY_THD, strlen(STREAM_BOUNDARY_THD));
      }
    } else {
      // HTTP/1.1 405 Method Not Allowed
      httpd_response_method_not_allowed(conn, NULL);
    }

    printf("Streaming_cb httpd_conn_close\r\n");
    httpd_conn_close(conn);
}

void ledon_cb(struct httpd_conn *conn)
{
  digitalWrite(LED_PIN, HIGH);
}

void ledoff_cb(struct httpd_conn *conn)
{
  digitalWrite(LED_PIN, LOW);
}

void Streaming_cb(struct httpd_conn *conn)
{
  streaming_httpd(conn);
}

static void example_httpd_thread(void *param)
{
	/* To avoid gcc warnings */
	(void) param;

	httpd_reg_page_callback("/", homepage_cb);
  httpd_reg_page_callback("/Streaming", Streaming_cb);
	httpd_reg_page_callback("/ledon", ledon_cb);
  httpd_reg_page_callback("/ledoff", ledoff_cb);

	if (httpd_start(80, 5, 4096, HTTPD_THREAD_SINGLE, HTTPD_SECURE_NONE) != 0) {
		printf("ERROR: httpd_start");
		httpd_clear_page_callbacks();
	}

	vTaskDelete(NULL);
}

void streaming_httpd(struct httpd_conn *conn) {
	if (xTaskCreate(streaming_httpd_thread, ((const char *)"streaming_httpd_thread"), 512, conn, tskIDLE_PRIORITY + 1, NULL) != pdPASS) {
		printf("\n\r%s xTaskCreate(streaming_httpd_thread) failed", __FUNCTION__);
	}
}

void example_httpd(void) {
	if (xTaskCreate(example_httpd_thread, ((const char *)"example_httpd_thread"), 2048, NULL, tskIDLE_PRIORITY + 1, NULL) != pdPASS) {
		printf("\n\r%s xTaskCreate(example_httpd_thread) failed", __FUNCTION__);
	}
}
