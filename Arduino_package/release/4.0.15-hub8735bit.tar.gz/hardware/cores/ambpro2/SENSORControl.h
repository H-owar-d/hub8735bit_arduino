#ifndef HUB8735_BIT_SENSORCONTROL_H
#define HUB8735_BIT_SENSORCONTROL_H

#include "Arduino.h"
#include "LSM303_Accel.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#define MIN_TEMP_ADC	232.0	
#define MAX_TEMP_ADC	836.0
#define TEMP_ADC_OFFSET	12.0

#define GESTURE_SHAKE				0
#define GESTURE_USBUP				1
#define GESTURE_USBDOWN			2
#define GESTURE_CAMUP				3
#define GESTURE_CAMDOWN			4
#define GESTURE_TILTLEFT		5
#define GESTURE_TILTRIGHT		6
#define GESTURE_FALL				7
#define GESTURE_3G					8
#define GESTURE_6G					9
#define GESTURE_8G					10

typedef struct compass_cal_s {
  int minX = 0; ///< x-axis data
  int minY = 0; ///< y-axis data
  int minZ = 0; ///< z-axis data
  int maxX = 0; ///< x-axis data
  int maxY = 0; ///< y-axis data
  int maxZ = 0; ///< z-axis data
} calibrationCount;

class Temperature_sensor{
private:		
    
public:

    void begin(void);
    void end(void);
    float temperature(void);
    
};

class Light_sensor{
private:		
    
public:

    void begin(void);
    void end(void);
    int readLightR_value(void);
    int readLightL_value(void);
    
};

class compass_sensor{
private:		
    
public:

    void begin(void);
    void end(void);
    uint8_t readRegister(int address);
    uint8_t writeRegister(int address, int data);
    void readRawData();
    float heading();
    float heading_yz();
    float heading_adj();
    float heading_yz_adj();
    void getEvent();
    void calibration();
    calibrationCount getCalCount();
    
};

class acc_sensor{
private:		
    
public:

    void begin(void);
    void end(void);
    uint8_t readRegister(int address);
    uint8_t writeRegister(int address, int data);
    float temperature();
    lsm303_accel_range_t getRange();
    lsm303_accel_mode_t getMode();
    void setRange(lsm303_accel_range_t new_range);
    void setMode(lsm303_accel_mode_t new_mode);
    void readRawData();
    void getEvent();
    uint8_t getShift(lsm303_accel_mode_t mode);
    float getLSB(lsm303_accel_mode_t mode);
    bool IsGesture(int type);
    bool check_g(int type);
    int16_t getValue(int type);
};

#endif
