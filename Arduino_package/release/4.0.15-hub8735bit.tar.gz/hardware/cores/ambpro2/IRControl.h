#ifndef HUB8735_BIT_IRCONTROL_H
#define HUB8735_BIT_IRCONTROL_H

#include "Arduino.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


class IRControl{
private:		
    
public:

    void begin(void);
    void end(void);
    int readIR_R(void);
    int readIR_L(void);
    int readIR_R_base(void);
    int readIR_L_base(void);
    bool checkIR_R(int value);
    bool checkIR_L(int value);
    
};

#endif
