#include <section_config.h>

SDRAM_DATA_SECTION
unsigned char *mp3_data;
unsigned int mp3_data_len;
