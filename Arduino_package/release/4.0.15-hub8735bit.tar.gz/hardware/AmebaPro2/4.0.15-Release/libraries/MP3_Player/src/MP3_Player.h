/**
  * @Date: 2025/04/08
  * @Creator: Bob_Su
  */
#ifndef __MP3PLAYER_H__
#define __MP3PLAYER_H__

#include "Arduino.h"
#include "AmebaFatFS.h"

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus
#include "wsMP3Player.h"
#ifdef __cplusplus
}
#endif //__cplusplus

class MP3Player {
private:
    static void PlayComplete(void);

public:
    MP3Player();
    /**
     * @brief Start MP3 Player
     * @param None
     * @retval None
     */
    void begin(void);
    /**
     * @brief Play MP3 file
     * @param &file: File handler
     * @retval Result (0:Success Other:Failed)
     */
    char play(File &file);
    /**
     * @brief Play MP3 raw data
     * @param *buf: MP3 raw data buffer
     * @param len: MP3 raw data buffer length
     * @param status: Player Control
     * @retval Result (0:Success Other:Failed)
     */
    char play(char *buf, unsigned long len, char ctrl);
};

#endif //MP3PLAYER