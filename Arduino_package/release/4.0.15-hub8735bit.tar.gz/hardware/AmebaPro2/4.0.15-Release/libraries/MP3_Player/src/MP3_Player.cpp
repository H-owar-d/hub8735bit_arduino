/**
  * @Date: 2025/04/08
  * @Creator: Bob_Su
  */
#include "MP3_Player.h"

#define READ_SIZE                                   1024

void MP3Player::PlayComplete(void)
{

}

MP3Player::MP3Player()
{

}
/**
 * @brief Start MP3 Player
 * @param None
 * @retval None
 */
void MP3Player::begin(void)
{
    wsMP3Player_init(PlayComplete);
}
/**
 * @brief Play MP3 file
 * @param &file: File handler
 * @retval Result (0:Success Other:Failed)
 */
char MP3Player::play(File &file)
{
    unsigned char *rd_buf = new unsigned char[READ_SIZE];
    unsigned int rd_size;
    unsigned char ret;
    int size = file.available();

    if(size > 0)
    {
        rd_size = file.read(rd_buf, READ_SIZE);
        if(rd_size > 0)
        {
            if(MP3Player::play((char *)rd_buf, rd_size, PLAYER_CONTROL_START))
            {
                return 1;
            }
        }
        while(1)
        {
            rd_size = file.read(rd_buf, READ_SIZE);
            if(rd_size <= 0)
            {
                MP3Player::play((char *)rd_buf, rd_size, PLAYER_CONTROL_STOP);
                break;
            }
            else
            {
                if(MP3Player::play((char *)rd_buf, rd_size, PLAYER_CONTROL_CONTINUE))
                {
                    return 1;
                }
            }
        }
    }
    return 0;
}
/**
 * @brief Play MP3 raw data
 * @param *buf: MP3 raw data buffer
 * @param len: MP3 raw data buffer length
 * @param status: Player Control
 * @retval Result (0:Success Other:Failed)
 */
char MP3Player::play(char *buf, unsigned long len, char ctrl)
{
    unsigned char ret;
    //printf("[%s] Start\r\n", __func__);
    if((buf != 0) && (len != 0))
    {
        do
        {
            ret = wsMP3Player_playRaw((uint8_t *)buf, len, (PlayerControl_Typedef)ctrl);
        }while (ret == MP3_PLAYER_BUSY);

        if(ret)
        {
            do
            {
                ret = wsMP3Player_playRaw((uint8_t *)buf, len, PLAYER_CONTROL_STOP);
            }while (ret == MP3_PLAYER_BUSY);
            return 1;
        }
        return 0;
    }
    return 1;
}