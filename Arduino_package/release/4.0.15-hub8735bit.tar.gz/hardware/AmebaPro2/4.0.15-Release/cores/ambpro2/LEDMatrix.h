#ifndef HUB8735_BIT_LEDMATRIX_H
#define HUB8735_BIT_LEDMATRIX_H

#include "Arduino.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

inline void clearshowArray();
void display_go_right(int character[5][5], int go_speed);
void display_go(int character[5][5], int go_speed);

class LED_Matrix{
private:		
    
public:
		int read_xy(uint32_t x, uint32_t y);
    void display_xy(uint32_t x, uint32_t y , bool bOn, bool bInvert);
    void display(uint32_t index, int chartype);
    void clear(void);
    void showString(char *string, int direct);
    void showString(String string, int direct);
    bool showNumbers(uint32_t number, int direct);
    bool test(uint32_t number, int direct);
    void begin(void);
    void end(void);
    void config(int go_time=10);
    //void showLEDs(int character[5][5]);
    void showLEDs(String str);
    void showArrow(uint32_t index);
    void showIcon(uint32_t index);
};

#endif
