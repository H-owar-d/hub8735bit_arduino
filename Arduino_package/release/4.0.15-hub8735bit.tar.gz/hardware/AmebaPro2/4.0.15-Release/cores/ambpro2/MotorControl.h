#ifndef HUB8735_BIT_MOTORCONTROL_H
#define HUB8735_BIT_MOTORCONTROL_H

#include "Arduino.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


class MotorControl{
private:		
    
public:

    void begin(void);
    void end(void);
    void forward();
    void backward();
    void rightward();
    void leftward();
    void stopwalk();
    void stopturn();
    void stopall();
};

#endif
