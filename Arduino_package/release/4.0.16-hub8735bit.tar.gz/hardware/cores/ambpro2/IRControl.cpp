#include "IRControl.h"
#include "Arduino.h"

void IRControl::begin(void) {
  // put your setup code here, to run once:
  pinMode(P12, OUTPUT);
  //pinMode(P1, INPUT_PULLDOWN);
  //pinMode(P2, INPUT_PULLDOWN);
  pinMode(P1, INPUT);
  pinMode(P2, INPUT);

  //digitalWrite(P12,HIGH);
}

void IRControl::end(void) {
	pinRemoveMode(P12);
	pinRemoveMode(P1);
	pinRemoveMode(P2);
}

int IRControl::readIR_R_base(void) {
	int anadata = 0;
	anadata = analogRead(P1);
	return anadata;
}

int IRControl::readIR_R(void) {
	int anadata = 0;
	int anadata1 = 0;
	int anadata2 = 0;
	anadata = analogRead(P1);
	//printf("R anadata 1 = %d\r\n", anadata);
	digitalWrite(P12,HIGH);
	delay(100);
	anadata1 = analogRead(P1);
	anadata2 = anadata1 - anadata;
	//printf("R anadata 1 = %d(%d)\r\n", anadata1, anadata2 );
	//delay(100);
	digitalWrite(P12,LOW);
	//return (int)analogRead(P1);
	return anadata2;
}

int IRControl::readIR_L_base(void) {
	int anadata = 0;
	anadata = analogRead(P2);
	return anadata;
}

int IRControl::readIR_L(void) {
	int anadata = 0;
	int anadata1 = 0;
	int anadata2 = 0;
	anadata = analogRead(P2);
	//printf("L anadata 1 = %d\r\n", anadata);
	digitalWrite(P12,HIGH);
	delay(100);
	anadata1 = analogRead(P2);
	anadata2 = anadata1 - anadata;
	//printf("L anadata 1 = %d(%d)\r\n", anadata1, anadata2 );
	//delay(100);
	digitalWrite(P12,LOW);
	//return (int)analogRead(P2);
	return anadata2;
}

bool IRControl::checkIR_R(int value) {
	int anadata = 0;
	anadata = analogRead(P1);
	digitalWrite(P12,HIGH);
	delay(100);
	anadata = analogRead(P1) - anadata;
	printf("R anadata  = %d\r\n", anadata);
	//delay(100);
	digitalWrite(P12,LOW);
	if (anadata >= value )	
		return true;
	else
		return false;
/*	if ((int)analogRead(P1) >= value )
		return true;
	else
		return false;
		*/
}

bool IRControl::checkIR_L(int value) {
	int anadata = 0;
	anadata = analogRead(P2);
	digitalWrite(P12,HIGH);
	delay(100);
	anadata = analogRead(P2) - anadata;
	printf("L anadata  = %d\r\n", anadata);
	//delay(100);
	digitalWrite(P12,LOW);
	if (anadata >= value )	
		return true;
	else
		return false;
/*
	if ((int)analogRead(P2) >= value )
		return true;
	else
		return false;
		*/
}