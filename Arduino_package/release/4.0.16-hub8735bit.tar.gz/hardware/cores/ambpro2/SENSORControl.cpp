#include "SENSORControl.h"
#include "Arduino.h"
#include "i2c_api.h"
#include "LSM303_Accel.h"

#include <math.h>

static i2c_t   i2cmaster;
static lsm303AccelData raw;
static lsm303AMagData mag_raw;
static acceleration_event	a_event;
static acceleration_event	temp_event;
	
static magnetic_event m_event;

#define EXT_I2C_MTR_SDA   PE_4
#define EXT_I2C_MTR_SCL   PE_3

bool bi2c_init_done = false;

static float MagMinX = 0.0;
static float MagMaxX = 0.0;
static float MagMinY = 0.0;
static float MagMaxY = 0.0;
static float MagMinZ = 0.0;
static float MagMaxZ = 0.0;
static calibrationCount compass_count;
/*
int countMinX = 0;
int countMaxX = 0;
int countMinY = 0;
int countMaxY = 0;
int countMinZ = 0;
int countMaxZ = 0;
*/
static float Xoffset = 0.0;
static float Yoffset = 0.0;
static float Zoffset = 0.0;

void i2c_init()
{
	if (!bi2c_init_done)
	{
  	i2c_init(&i2cmaster, EXT_I2C_MTR_SDA, EXT_I2C_MTR_SCL);
  	bi2c_init_done = true;
  }
  i2c_frequency(&i2cmaster, 400000);
}

int i2c_read_data(int slave ,int address)
{
  char buf[3];
  int tmp = 0;
  char *readbuf = (char *)&tmp;

  readbuf[0] = 0x0;
  buf[0] = (char)(address & 0xff);
  
  i2c_write(&i2cmaster, slave, &buf[0], 1, 1);
  i2c_read(&i2cmaster, slave, &readbuf[0], 1, 1);
  delay(5);
  
  //printf("i2c[0x%x], result = 0x%x\r\n", buf[0], (unsigned char)readbuf[0]);
  return readbuf[0];
}

int i2c_write_data(int slave ,int address, int data)
{
  char buf[3];
  int tmp = 0;
  char *readbuf = (char *)&tmp;

  readbuf[0] = 0x0;
  buf[0] = address;
  buf[1] = data;
  
  i2c_write(&i2cmaster, slave, &buf[0], 2, 1);
  //i2c_read(&i2cmaster, slave, &readbuf[0], 1, 1);
  delay(5);
  //printf("i2c[0x%x], result = 0x%x\r\n", buf[0], readbuf[0]);
  return readbuf[0];
}

void Temperature_sensor::begin(void) {
  // put your setup code here, to run once:
	pinMode(A0, INPUT);
}

float Temperature_sensor::temperature(void) {
  // put your setup code here, to run once:
	int ADC_value = 0;
	float T_value = 255.0;
	
	ADC_value = (float)analogRead(A0);
	if ((ADC_value < MIN_TEMP_ADC) || (ADC_value > MAX_TEMP_ADC))
	{			
			printf("Over range, current adc is %d\r\n", ADC_value);
	}
	else
	{
			T_value = 60.0 - (float)((ADC_value - MIN_TEMP_ADC + TEMP_ADC_OFFSET) / 5);
	}
		
	printf("ADC_value = %d, (%f)\r\n", ADC_value, T_value);
	return T_value;
}

void Light_sensor::begin(void) {
  // put your setup code here, to run once:
	pinMode(A4, INPUT);
	pinMode(A5, INPUT);
}


int Light_sensor::readLightR_value(void) {
  // put your setup code here, to run once:
	int ADC_value = 0;

	ADC_value = (int)analogRead(A4);
		
	printf("readLightR_value = %d\r\n", ADC_value);
	return ADC_value;
}

int Light_sensor::readLightL_value(void) {
  // put your setup code here, to run once:
	int ADC_value = 0;

	ADC_value = (int)analogRead(A5);
		
	printf("readLightR_value = %d\r\n", ADC_value);
	return ADC_value;
}

void compass_sensor::begin(void) {
  // put your setup code here, to run once:
	i2c_init();

	i2c_write_data(LSM303_ADDRESS_MAG, LSM303_REGISTER_MAG_CFG_REG_A_M, 0x02);	//idle1
  i2c_write_data(LSM303_ADDRESS_MAG, LSM303_REGISTER_MAG_CFG_REG_C_M, 0x10);	//enable bdu
  i2c_write_data(LSM303_ADDRESS_MAG, LSM303_REGISTER_MAG_CFG_REG_A_M, 0x0E);	//Enable the accelerometer (100Hz)
  i2c_write_data(LSM303_ADDRESS_MAG, LSM303_REGISTER_MAG_CFG_REG_A_M, 0x04);	//continue mode
  
	int data = i2c_read_data(LSM303_ADDRESS_MAG, LSM303_REGISTER_MAG_WHO_AM_I_M);
	printf("[ECOMPASS]who am i = 0x%x\r\n", data);
}

void compass_sensor::readRawData() {
  // this sucks but using one register with a 6 byte read to buffer doesn't
  // work.
  uint8_t xlo = i2c_read_data(LSM303_ADDRESS_MAG, LSM303_REGISTER_MAG_OUTX_L_REG_M);
  uint8_t xhi = i2c_read_data(LSM303_ADDRESS_MAG, LSM303_REGISTER_MAG_OUTX_H_REG_M);
  uint8_t ylo = i2c_read_data(LSM303_ADDRESS_MAG, LSM303_REGISTER_MAG_OUTY_L_REG_M);
  uint8_t yhi = i2c_read_data(LSM303_ADDRESS_MAG, LSM303_REGISTER_MAG_OUTY_H_REG_M);
  uint8_t zlo = i2c_read_data(LSM303_ADDRESS_MAG, LSM303_REGISTER_MAG_OUTZ_L_REG_M);
  uint8_t zhi = i2c_read_data(LSM303_ADDRESS_MAG, LSM303_REGISTER_MAG_OUTZ_H_REG_M);

  mag_raw.x = (int16_t)(xlo | (xhi << 8));
  mag_raw.y = (int16_t)(ylo | (yhi << 8));
  mag_raw.z = (int16_t)(zlo | (zhi << 8));
  //printf("mag x=0x%x, y=0x%x, z=0x%x\r\n",(unsigned short)mag_raw.x,(unsigned short)mag_raw.y,(unsigned short)mag_raw.z);
}

uint8_t compass_sensor::readRegister(int address) {
  // put your setup code here, to run once:
	return (uint8_t)i2c_read_data(LSM303_ADDRESS_MAG ,address);
}

uint8_t compass_sensor::writeRegister(int address, int data) {
  // put your setup code here, to run once:
	return (uint8_t)i2c_write_data(LSM303_ADDRESS_MAG ,address, data);
}

void compass_sensor::getEvent() {
  // this sucks but using one register with a 6 byte read to buffer doesn't
  // work.
  readRawData();

  m_event.x = (float)mag_raw.x * LIS2MDL_MAG_LSB * LIS2MDL_MILLIGAUSS_TO_MICROTESLA;
  m_event.y = (float)mag_raw.y * LIS2MDL_MAG_LSB * LIS2MDL_MILLIGAUSS_TO_MICROTESLA;
  m_event.z = (float)mag_raw.z * LIS2MDL_MAG_LSB * LIS2MDL_MILLIGAUSS_TO_MICROTESLA;
  //printf("x=%f, y=%f, z=%f\r\n",m_event.x ,m_event.y ,m_event.z);
}

float compass_sensor::heading_yz() {
  getEvent();
  float Pi = 3.14159;

  // Calculate the angle of the vector y,x
  float heading = (atan2(m_event.y, m_event.z) * (180 / Pi) + 180);

  // Normalize to 0-360
  if (heading < 0)
  {
    heading = 360 + heading;
  }
  printf("compass heading yz = %f\r\n", heading);
  return heading;
}

float compass_sensor::heading() {
  getEvent();
  float Pi = 3.14159;

  // Calculate the angle of the vector y,x
  //float heading = (atan2(m_event.x, -m_event.y) * (180.0 / Pi) + 180);
  // Calculate the angle of the vector y,x
  float heading = (atan2((m_event.x - Xoffset), (-m_event.y - Yoffset)) * (180 / Pi) + 180);

  // Normalize to 0-360
  if (heading < 0)
  {
    printf("<0 compass heading = %f\r\n", heading);
    heading = 360 + heading;
  }
  printf("compass heading = %f\r\n", heading);
  
  return heading;
}

void compass_sensor::calibration() {
	getEvent();
	if (m_event.x < MagMinX)
	{
    MagMinX = m_event.x;
    //countMinX++;
    compass_count.minX++;
  }
  
  if (m_event.x > MagMaxX)
  {
    MagMaxX = m_event.x;
    //countMaxX++;
    compass_count.maxX++;
	}
	
  if (m_event.y < MagMinY)
  {
    MagMinY = m_event.y;
    //countMinY++;
    compass_count.minY++;
  }
  
  if (m_event.y > MagMaxY)
  {
    MagMaxY = m_event.y;
    //countMaxY++;
    compass_count.maxY++;
	}
	
  if (m_event.z < MagMinZ)
  {
    MagMinZ = m_event.z;
    //countMinZ++;
    compass_count.minZ++;
  }
  
  if (m_event.z > MagMaxZ)
  {
    MagMaxZ = m_event.z;
    //countMaxZ++;
    compass_count.maxZ++;
  } 
  
  //printf("countMin: %d %d %d\r\n", countMinX, countMinY, countMinZ);
  //printf("countMax: %d %d %d\r\n", countMaxX, countMaxY, countMaxZ);
  //printf("Mag Minimums: %f %f %f\r\n", MagMinX, MagMinY, MagMinZ);
  //printf("Mag Maximums: %f %f %f\r\n", MagMaxX, MagMaxY, MagMaxZ);
   
  Xoffset = (MagMaxX + MagMinX) / 2;  
  Yoffset = (MagMaxY + MagMinY) / 2;
  Zoffset = (MagMaxZ + MagMinZ) / 2; 
}

calibrationCount compass_sensor::getCalCount()
{
		return compass_count;
}

bool compass_sensor::isCalibrated()
{
    float rangeX = MagMaxX - MagMinX;
    float rangeY = MagMaxY - MagMinY;
    float rangeZ = MagMaxZ - MagMinZ;

    const float RANGE_THRESHOLD = 60.0; // �ھ� sensor sensitivity �վ�
    const float AXIS_MIN_THRESHOLD = 60.0; // �Y�Y�b�e���ण��A�]�i��e

    bool x_ok = rangeX >= RANGE_THRESHOLD;
    bool y_ok = rangeY >= RANGE_THRESHOLD;
    bool z_ok = rangeZ >= AXIS_MIN_THRESHOLD; // �i��e����
		
		if(!x_ok || !y_ok || !z_ok)
		{
    	//printf("Range X: %.2f, Y: %.2f, Z: %.2f\r\n", rangeX, rangeY, rangeZ);
    	printf("Calibration in progress. Keep rotating in a figure-eight motion\r\n");
    }
    return x_ok && y_ok && z_ok;
}

float compass_sensor::heading_yz_adj() {
  getEvent();
  float Pi = 3.14159;

  // Calculate the angle of the vector y,x
  float heading = (atan2((m_event.y - Yoffset), (m_event.z - Zoffset)) * (180 / Pi) + 180);

  // Normalize to 0-360
  if (heading < 0)
  {
    heading = 360 + heading;
  }
  printf("compass heading yz adj = %f\r\n", heading);
  return heading;
}

float compass_sensor::heading_adj() {
  getEvent();
  float Pi = 3.14159;

  // Calculate the angle of the vector y,x
  float heading = (atan2((m_event.x - Xoffset), (-m_event.y - Yoffset)) * (180 / Pi) + 180);

  // Normalize to 0-360
  if (heading < 0)
  {
  	printf("<0 compass heading adj = %f\r\n", heading);
    heading = 360 + heading;
  }
  printf("compass heading adj = %f\r\n", heading);
  return heading;
}
/*
float compass_sensor::heading_tilt_compensated()
{
		getEvent();
    acc.getEvent(); // ��s m_event.x/y/z�]�ϤO�p�^�P�[�t�� acc.x/y/z ���
    
    float Pi = 3.14159;

    // 1. Apply offset correction
    float mag_x = m_event.x - Xoffset;
    float mag_y = m_event.y - Yoffset;
    float mag_z = m_event.z - Zoffset;

    float acc_x = a_event.x;//acc.x;
    float acc_y = a_event.y;//acc.y;
    float acc_z = a_event.z;//acc.z;

    // 2. �p�� roll �P pitch
    float roll = atan2(acc_y, acc_z);
    float pitch = atan2(-acc_x, sqrt(acc_y * acc_y + acc_z * acc_z));

    // 3. �ɱ׸��v�᪺�ϤO��
    float Xh = mag_x * cos(pitch) + mag_z * sin(pitch);
    float Yh = mag_x * sin(roll) * sin(pitch) + mag_y * cos(roll) - mag_z * sin(roll) * cos(pitch);

    // 4. �p�� heading
    float heading = atan2(Yh, Xh) * (180.0 / Pi);
    if (heading < 0)
    {
        heading += 360;
    }

    printf("Tilt-compensated heading = %f\r\n", heading);
    return heading;
}
*/
/*-------------------------------------------------------------------------------------
Accel
-------------------------------------------------------------------------------------*/
void acc_sensor::begin(void) {
  // put your setup code here, to run once:
  i2c_init();
  
  i2c_write_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG1_A, 0x57);	//Enable the accelerometer (100Hz)
  //i2c_write_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG4_A, 0x00);	//set +-2G range
  i2c_write_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG4_A, 0x10);	//set +-4G range
  //i2c_write_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG4_A, 0x20);	//set +-8G range
  i2c_write_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG4_A, 0x18);	//hi resolution
  
  i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_WHO_AM_I);
}

void acc_sensor::setRange(lsm303_accel_range_t new_range) {
  // put your setup code here, to run once:
  int range = i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG4_A);
  range &= (0x30);
  range |= (new_range << 4);
  i2c_write_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG4_A, range);
  
}

lsm303_accel_range_t acc_sensor::getRange() {
  // put your setup code here, to run once:
  int range = i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG4_A);
 	//printf("[getRange]range = 0x%x\r\n", (unsigned char)range);
 	range &= (0x30);
 	//printf("[getRange]range&0x30 = 0x%x\r\n", range);
  return (lsm303_accel_range_t)(range >> 4);
}

void acc_sensor::setMode(lsm303_accel_mode_t new_mode) {
		int ctrl_1 = i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG1_A);
		int ctrl_4 = i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG4_A);
		ctrl_1 &= (0x08);
		ctrl_1 |= (((new_mode& 0x2)>>1) << 3);
  	i2c_write_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG1_A, ctrl_1);
  	ctrl_4 &= (0x08);
  	ctrl_4 |= (((new_mode& 0x1)) << 3);
  	i2c_write_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG4_A, ctrl_4);
  	//printf("setMode not ready, need verify\r\n");
}

lsm303_accel_mode_t acc_sensor::getMode(void) {
		int ctrl_1 = i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG1_A);
		int ctrl_4 = i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_CTRL_REG4_A);
		//lsm303_accel_mode_t mode = LSM303_MODE_NORMAL;
		//printf("getMode not ready, need verify\r\n");
		int mode = (((ctrl_1 & 0x08)>>3)<<1) + ((ctrl_4 &0x08)>>3);
		//printf("[getMode]mode= 0x%x\r\n", mode);
		return (lsm303_accel_mode_t)mode;
}


void acc_sensor::readRawData() {
  // this sucks but using one register with a 6 byte read to buffer doesn't
  // work.
  uint8_t xlo = i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_OUT_X_L_A);
  uint8_t xhi = i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_OUT_X_H_A);
  uint8_t ylo = i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_OUT_Y_L_A);
  uint8_t yhi = i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_OUT_Y_H_A);
  uint8_t zlo = i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_OUT_Z_L_A);
  uint8_t zhi = i2c_read_data(LSM303_ADDRESS_ACCEL, LSM303_REGISTER_ACCEL_OUT_Z_H_A);

  raw.x = (int16_t)(xlo | (xhi << 8))>>4;
  raw.y = (int16_t)(ylo | (yhi << 8))>>4;
  raw.z = (int16_t)(zlo | (zhi << 8))>>4;
  //printf("x=0x%x, y=0x%x, z=0x%x\r\n",(unsigned short)raw.x,(unsigned short)raw.y,(unsigned short)raw.z);
  //printf("x=%d, y=%d, z=%d\r\n",raw.x,raw.y,raw.z);
}

float acc_sensor::getLSB(lsm303_accel_mode_t mode) {
  float lsb = 0;
  lsm303_accel_range_t range = getRange();
  //printf("[getLSG]range = %d\r\n", range);
  if (mode == LSM303_MODE_NORMAL) {
    switch (range) {
    case LSM303_RANGE_2G:
      lsb = 0.0039;
      break;
    case LSM303_RANGE_4G:
      lsb = 0.00782;
      break;
    case LSM303_RANGE_8G:
      lsb = 0.01563;
      break;
    case LSM303_RANGE_16G:
      lsb = 0.0469;
      break;
    }
  }

  else if (mode == LSM303_MODE_HIGH_RESOLUTION) {
    switch (range) {
    case LSM303_RANGE_2G:
      lsb = 0.00098;
      break;
    case LSM303_RANGE_4G:
      lsb = 0.00195;
      break;
    case LSM303_RANGE_8G:
      lsb = 0.0039;
      break;
    case LSM303_RANGE_16G:
      lsb = 0.01172;
      break;
    }
  } else if (mode == LSM303_MODE_LOW_POWER) {
    switch (range) {
    case LSM303_RANGE_2G:
      lsb = 0.01563;
      break;
    case LSM303_RANGE_4G:
      lsb = 0.03126;
      break;
    case LSM303_RANGE_8G:
      lsb = 0.06252;
      break;
    case LSM303_RANGE_16G:
      lsb = 0.18758;
      break;
    }
  }

  return lsb;
}

uint8_t acc_sensor::getShift(lsm303_accel_mode_t mode) {
  uint8_t shift = 0;
  switch (mode) {
  case LSM303_MODE_HIGH_RESOLUTION:
    shift = 4;
    break;
  case LSM303_MODE_NORMAL:
    shift = 6;
    break;
  case LSM303_MODE_LOW_POWER:
    shift = 8;
    break;
  }

  return shift;
}

int16_t acc_sensor::getValue(int type)
{
		
		readRawData();
		if (type == 1)
			return raw.x*2;
		else if (type == 2)
			return raw.y*2;
		else if (type == 3)
			return raw.z*2;
		else
			return sqrt((float)raw.x*(float)raw.x + (float)raw.y*(float)raw.y + (float)raw.z*(float)raw.z)*2;
}

void acc_sensor::getEvent() {
  // this sucks but using one register with a 6 byte read to buffer doesn't
  // work.
  readRawData();
  lsm303_accel_mode_t mode = getMode();
  
  float lsb = getLSB(mode);
  uint8_t shift = getShift(mode);
  a_event.x = (float)(raw.x >> shift) * lsb * SENSORS_GRAVITY_STANDARD;
  a_event.y = (float)(raw.y >> shift) * lsb * SENSORS_GRAVITY_STANDARD;
  a_event.z = (float)(raw.z >> shift) * lsb * SENSORS_GRAVITY_STANDARD;
  printf("x=%f, y=%f, z=%f\r\n",a_event.x ,a_event.y ,a_event.z);
}

uint8_t acc_sensor::readRegister(int address) {
  // put your setup code here, to run once:
	return (uint8_t)i2c_read_data(LSM303_ADDRESS_ACCEL ,address);
}

float acc_sensor::temperature() {
  // put your setup code here, to run once:
  uint16_t u16_data = 0;
	float f_result;
	
	i2c_write_data(LSM303_ADDRESS_ACCEL,0x1F, 0xC0);
  //i2c_read_data(LSM303_ADDRESS_ACCEL,0x1F);
  
  int reg23 = i2c_read_data(LSM303_ADDRESS_ACCEL,0x23);
  
  i2c_write_data(LSM303_ADDRESS_ACCEL,0x23, reg23 | 0x80);
  //i2c_read_data(LSM303_ADDRESS_ACCEL,0x23);
  
 	//u16_data |= i2c_read_data(LSM303_ADDRESS_ACCEL,0x0C);
 	uint8_t reg0d = i2c_read_data(LSM303_ADDRESS_ACCEL,0x0d);
 	uint8_t reg0c = i2c_read_data(LSM303_ADDRESS_ACCEL,0x0c);
 	printf("[Temperature]reg0d = 0x%x, reg0c = 0x%x\r\n", (unsigned char)reg0d, (unsigned char)reg0c);
 	if ((reg0d & 0x80) != 0)
 	{
 			reg0d = ~reg0d + 1;
 			printf("[Temperature]2's reg0d = 0x%x\r\n", reg0d);
 			u16_data = ((reg0d)<< 8) + reg0c;
 			printf("[Temperature]u16_data = 0x%x\r\n", (unsigned short)u16_data);
 			f_result = (float)25.0 - ((u16_data /64.0f) / 4.0f);
 	}
 	else
 	{
  		u16_data = (reg0d<< 8) + reg0c;  
  		printf("[Temperature]u16_data = 0x%x\r\n", (unsigned short)u16_data);
  		f_result = (float)((u16_data /64.0f) / 4.0f) + 25.0f;
  }
  
  printf("[Temperature]f_result = %f\r\n", f_result);
  return f_result;
}

uint8_t acc_sensor::writeRegister(int address, int data) {
  // put your setup code here, to run once:
	return (uint8_t)i2c_write_data(LSM303_ADDRESS_ACCEL ,address, data);
}

bool acc_sensor::check_g(int type)
{	
		bool flag_shake = 0;
		bool flag_3g = 0;
		bool flag_6g = 0;
		bool flag_8g = 0;
		bool flag_fall = 0;
		float result_x, result_y, result_z;
		for(int i=0;i<3;i++)
		{
				getEvent();
				result_x = a_event.x - temp_event.x;
				result_y = a_event.y - temp_event.y;
				result_z = a_event.z - temp_event.z;
				//printf("abs x %f y %f z %f\r\n",result_x, result_y,result_z );
				if ((abs(result_x) > 72) || (abs(result_y) > 72) || (abs(result_z) > 72))
				{
						flag_8g = 1;
				}
				else if((abs(result_x) > 54) || (abs(result_y) > 54) || (abs(result_z) > 54))
				{
						flag_6g = 1;
				}
				else if((abs(result_x) > 27) || (abs(result_y) > 27) || (abs(result_z) > 27))
				{
						flag_3g = 1;
				}
				else if((abs(result_x) > 9) || (abs(result_y) > 9) || (abs(result_z) > 9))
				{
						flag_shake = 1;
				}
				else if (abs(result_y) < 5)
				{
						flag_fall = 1;
				}
				//temp_event.x = a_event.x;
				//temp_event.x = a_event.x;
				//temp_event.x = a_event.x;			
		}
		
		switch(type)
		{
				case GESTURE_SHAKE:
					return flag_shake;
					break;
				case GESTURE_FALL:
					return flag_fall;
					break;
				case GESTURE_3G:
					return flag_3g;
					break;
				case GESTURE_6G:
					return flag_6g;
					break;
				case GESTURE_8G:
					return flag_8g;
					break;	
				default:
					return 0; 		
		}
}

bool acc_sensor::IsGesture(int type) {
  // put your setup code here, to run once:
	getEvent();
	temp_event.x = a_event.x;
	temp_event.y = a_event.y;
	temp_event.z = a_event.z;
	switch(type)
	{
			case GESTURE_SHAKE:
				return check_g(GESTURE_SHAKE);
				break;
			case GESTURE_USBUP:
				if (a_event.y > 9.0)
					return true;
				else
					return false;
				break;
			case GESTURE_USBDOWN:
				if (a_event.y < -9.0)
					return true;
				else
					return false;
				break;
			case GESTURE_CAMUP:
				if (a_event.z < -9.0)
					return true;
				else
					return false;
				break;
			case GESTURE_CAMDOWN:
				if (a_event.z > 9.0)
					return true;
				else
					return false;
				break;
			case GESTURE_TILTLEFT:
				if (a_event.x < -4.0)
					return true;
				else
					return false;
				break;
			case GESTURE_TILTRIGHT:
				if (a_event.x > 4.0)
					return true;
				else
					return false;
				break;
			case GESTURE_FALL:
				return check_g(GESTURE_FALL);
				break;
			case GESTURE_3G:
				return check_g(GESTURE_3G);
				break;
			case GESTURE_6G:
				return check_g(GESTURE_6G);
				break;
			case GESTURE_8G:
				return check_g(GESTURE_8G);
				break;
			default:
				return 0;			
	}
}