/*!
 * @file Adafruit_LSM303_Accel.h
 *
 */

#ifndef LSM303_ACCEL_H
#define LSM303_ACCEL_H

#if (ARDUINO >= 100)
#include "Arduino.h"
#else
#include "WProgram.h"
#endif


#define LSM303_ADDRESS_ACCEL (0x32 >> 1) //!< I2C address/bits, 0011001x
#define LSM303_ADDRESS_MAG 	 (0x3C	 >> 1) //!< I2C address/bits, 0011001x

#define _CHIP_ID 0x40       //!< Chip ID from WHO_AM_I register
#define LIS2MDL_MAG_LSB 1.5 //!< Sensitivity
#define LIS2MDL_MILLIGAUSS_TO_MICROTESLA                                       \
  0.1 //!< Conversion rate of Milligauss to Microtesla

/* Constants */
#define SENSORS_GRAVITY_EARTH (9.80665F) /**< Earth's gravity in m/s^2 */
#define SENSORS_GRAVITY_MOON (1.6F)      /**< The moon's gravity in m/s^2 */
#define SENSORS_GRAVITY_SUN (275.0F)     /**< The sun's gravity in m/s^2 */
#define SENSORS_GRAVITY_STANDARD (SENSORS_GRAVITY_EARTH)

/*!
 * @brief Registers
 */
typedef enum {                               // DEFAULT    TYPE
	LSM303_REGISTER_ACCEL_STATUS_REG_AUX_A = 0x07,	//000 0111		r
	LSM303_REGISTER_ACCEL_OUT_TEMP_L_A = 0x0C,	//						r
	LSM303_REGISTER_ACCEL_OUT_TEMP_H_A = 0x0D,	//						r
	LSM303_REGISTER_ACCEL_INT_COUNTER_REG_A = 0x0E,	//						r
  LSM303_REGISTER_ACCEL_WHO_AM_I = 0x0F,     // 00000111   r
  LSM303_REGISTER_ACCEL_TEMP_CFG_REG_A = 0x1F,	// 00000111   rw
  LSM303_REGISTER_ACCEL_CTRL_REG1_A = 0x20,  // 00000111   rw
  LSM303_REGISTER_ACCEL_CTRL_REG2_A = 0x21,  // 00000000   rw
  LSM303_REGISTER_ACCEL_CTRL_REG3_A = 0x22,  // 00000000   rw
  LSM303_REGISTER_ACCEL_CTRL_REG4_A = 0x23,  // 00000000   rw
  LSM303_REGISTER_ACCEL_CTRL_REG5_A = 0x24,  // 00000000   rw
  LSM303_REGISTER_ACCEL_CTRL_REG6_A = 0x25,  // 00000000   rw
  LSM303_REGISTER_ACCEL_REFERENCE_A = 0x26,  // 00000000   r
  LSM303_REGISTER_ACCEL_STATUS_REG_A = 0x27, // 00000000   r
  LSM303_REGISTER_ACCEL_OUT_X_L_A = 0x28,
  LSM303_REGISTER_ACCEL_OUT_X_H_A = 0x29,
  LSM303_REGISTER_ACCEL_OUT_Y_L_A = 0x2A,
  LSM303_REGISTER_ACCEL_OUT_Y_H_A = 0x2B,
  LSM303_REGISTER_ACCEL_OUT_Z_L_A = 0x2C,
  LSM303_REGISTER_ACCEL_OUT_Z_H_A = 0x2D,
  LSM303_REGISTER_ACCEL_FIFO_CTRL_REG_A = 0x2E,
  LSM303_REGISTER_ACCEL_FIFO_SRC_REG_A = 0x2F,
  LSM303_REGISTER_ACCEL_INT1_CFG_A = 0x30,
  LSM303_REGISTER_ACCEL_INT1_SOURCE_A = 0x31,
  LSM303_REGISTER_ACCEL_INT1_THS_A = 0x32,
  LSM303_REGISTER_ACCEL_INT1_DURATION_A = 0x33,
  LSM303_REGISTER_ACCEL_INT2_CFG_A = 0x34,
  LSM303_REGISTER_ACCEL_INT2_SOURCE_A = 0x35,
  LSM303_REGISTER_ACCEL_INT2_THS_A = 0x36,
  LSM303_REGISTER_ACCEL_INT2_DURATION_A = 0x37,
  LSM303_REGISTER_ACCEL_CLICK_CFG_A = 0x38,
  LSM303_REGISTER_ACCEL_CLICK_SRC_A = 0x39,
  LSM303_REGISTER_ACCEL_CLICK_THS_A = 0x3A,
  LSM303_REGISTER_ACCEL_TIME_LIMIT_A = 0x3B,
  LSM303_REGISTER_ACCEL_TIME_LATENCY_A = 0x3C,
  LSM303_REGISTER_ACCEL_TIME_WINDOW_A = 0x3D,
  LSM303_REGISTER_ACCEL_Act_THS_A = 0x3E,
  LSM303_REGISTER_ACCEL_Act_DUR_A = 0x3F,
  /*======================================================================*/
  LSM303_REGISTER_MAG_OFFSET_X_REG_L_M = 0x45,
  LSM303_REGISTER_MAG_OFFSET_X_REG_H_M = 0x46,
  LSM303_REGISTER_MAG_OFFSET_Y_REG_L_M = 0x47,
  LSM303_REGISTER_MAG_OFFSET_Y_REG_H_M = 0x48,
  LSM303_REGISTER_MAG_OFFSET_Z_REG_L_M = 0x49,
  LSM303_REGISTER_MAG_OFFSET_Z_REG_H_M = 0x4A,
  LSM303_REGISTER_MAG_WHO_AM_I_M = 0x4F,
  LSM303_REGISTER_MAG_CFG_REG_A_M = 0x60,
  LSM303_REGISTER_MAG_CFG_REG_B_M = 0x61,
  LSM303_REGISTER_MAG_CFG_REG_C_M = 0x62,
  LSM303_REGISTER_MAG_INT_CTRL_REG_M = 0x63,
  LSM303_REGISTER_MAG_INT_SOURCE_REG_M = 0x64,
  LSM303_REGISTER_MAG_INT_THS_L_REG_M = 0x65,
  LSM303_REGISTER_MAG_INT_THS_H_REG_M = 0x66,
  LSM303_REGISTER_MAG_STATUS_REG_M = 0x67,
  LSM303_REGISTER_MAG_OUTX_L_REG_M = 0x68,
  LSM303_REGISTER_MAG_OUTX_H_REG_M = 0x69,
  LSM303_REGISTER_MAG_OUTY_L_REG_M = 0x6A,
  LSM303_REGISTER_MAG_OUTY_H_REG_M = 0x6B,
  LSM303_REGISTER_MAG_OUTZ_L_REG_M = 0x6C,
  LSM303_REGISTER_MAG_OUTZ_H_REG_M = 0x6D
} lsm303AccelRegisters_t;

/*=========================================================================*/

/**************************************************************************/
/*!
    @brief  INTERNAL ACCELERATION DATA TYPE
*/
/**************************************************************************/
typedef struct lsm303AccelData_s {
  int16_t x; ///< x-axis data
  int16_t y; ///< y-axis data
  int16_t z; ///< z-axis data
} lsm303AccelData;

typedef struct lsm303MagData_s {
  int16_t x; ///< x-axis data
  int16_t y; ///< y-axis data
  int16_t z; ///< z-axis data
} lsm303AMagData;

typedef struct acceleration_event_s {
  float x; ///< x-axis value
  float y; ///< y-axis value
  float z; ///< z-axis value
} acceleration_event;

typedef struct magnetic_event_s {
  float x; ///< x-axis value
  float y; ///< y-axis value
  float z; ///< z-axis value
} magnetic_event;
/*=========================================================================*/

/*!
 * @brief Set of linear acceleration measurement ranges
 */
typedef enum range {
  LSM303_RANGE_2G,  ///< Measurement range from +2G to -2G (19.61 m/s^2)
  LSM303_RANGE_4G,  ///< Measurement range from +4G to -4G (39.22 m/s^2)
  LSM303_RANGE_8G,  ///< Measurement range from +8G to -8G (78.45 m/s^2)
  LSM303_RANGE_16G, ///< Measurement range from +16G to -16G (156.9 m/s^2)
} lsm303_accel_range_t;

/*!
 * @brief Set of different modes that can be used. Normal, high resolution, and
 * low power
 */
typedef enum mode {
  LSM303_MODE_NORMAL,          ///< Normal measurement mode; 10-bit
  LSM303_MODE_HIGH_RESOLUTION, ///< High resolution mode; 12-bit
  LSM303_MODE_LOW_POWER,       ///< Low power mode; 8-bit
} lsm303_accel_mode_t;

#define LSM303_ID (0b11010100) //!< Chip ID


/*!
  @brief Unified sensor driver for the accelerometer
*/
/*
class Adafruit_LSM303_Accel_Unified : public Adafruit_Sensor {
public:
  Adafruit_LSM303_Accel_Unified(int32_t sensorID = -1);

  bool begin(uint8_t i2c_addr = LSM303_ADDRESS_ACCEL, TwoWire *wire = &Wire);
  bool getEvent(sensors_event_t *);
  void getSensor(sensor_t *);

  void setRange(lsm303_accel_range_t);
  lsm303_accel_range_t getRange(void);

  lsm303_accel_mode_t getMode(void);
  void setMode(lsm303_accel_mode_t);

  void interruptsActiveHigh(bool);

private:
  int32_t _sensorID;

  lsm303AccelData raw; // Last read accelerometer data will be available here
  float getLSB(lsm303_accel_mode_t);
  uint8_t getShift(lsm303_accel_mode_t);

  void readRawData(void);

  Adafruit_I2CDevice *i2c_dev;
};
*/
#endif
