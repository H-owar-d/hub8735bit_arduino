#include "MotorControl.h"
#include "Arduino.h"
/*
int INA_MOTOR = P13; //GPF6 //go/back
int INB_MOTOR = P14; //GPF5 //go/back
int INC_MOTOR = P15; //GPF7	//turn right
int IND_MOTOR = P16; //GPF8	//turn left
*/
static bool bturnRL = false;
static bool bturnGOBACK = false;

void MotorControl::begin(void) {
  // put your setup code here, to run once:
/*pinMode(INA_MOTOR, OUTPUT);
  pinMode(INB_MOTOR, OUTPUT);
  pinMode(INC_MOTOR, OUTPUT);
  pinMode(IND_MOTOR, OUTPUT);
*/
  digitalWrite(INA_MOTOR,LOW);
  digitalWrite(INB_MOTOR,LOW);
  digitalWrite(INC_MOTOR,LOW);
  digitalWrite(IND_MOTOR,LOW);

}

void MotorControl::end(void) {

  pinRemoveMode(INA_MOTOR);
  pinRemoveMode(INB_MOTOR);
  pinRemoveMode(INC_MOTOR);
  pinRemoveMode(IND_MOTOR);
  
  bturnRL = false;
  bturnGOBACK = false;
}

void MotorControl::forward()
{
    digitalWrite(INA_MOTOR,HIGH);
    digitalWrite(INB_MOTOR,LOW);
    bturnGOBACK = true;
    
}

void MotorControl::backward()
{
    digitalWrite(INA_MOTOR,LOW);
    digitalWrite(INB_MOTOR,HIGH);
    bturnGOBACK = true;
}

void MotorControl::leftward()
{
    digitalWrite(INC_MOTOR,HIGH);
    digitalWrite(IND_MOTOR,LOW);
    bturnRL = true;
}

void MotorControl::rightward()
{
    digitalWrite(INC_MOTOR,LOW);
    digitalWrite(IND_MOTOR,HIGH);
    bturnRL = true;
}

void MotorControl::stopwalk()
{
    digitalWrite(INA_MOTOR,LOW);
    digitalWrite(INB_MOTOR,LOW);
    bturnGOBACK = false;
    
}

void MotorControl::stopturn()
{
    digitalWrite(INC_MOTOR,LOW);
    digitalWrite(IND_MOTOR,LOW);
    bturnRL = false;
}

void MotorControl::stopall()
{
    digitalWrite(INA_MOTOR,LOW);
    digitalWrite(INB_MOTOR,LOW);
    digitalWrite(INC_MOTOR,LOW);
    digitalWrite(IND_MOTOR,LOW);
    bturnRL = false;
    bturnGOBACK = false;
}