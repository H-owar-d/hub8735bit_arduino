﻿/*
┌───────────────────────────────────────────────────────┐
│				          HUB 8735 bit board									  │
└───────────────────────────────────────────────────────┘
More pin detail is in： 
Arduino15\packages\ideasHatch\hardware\AmebaPro2\4.0.15-Release\ameba_hub8735_bit\variant.cpp
-----------------------------------------------------------------------
											           ┌───────────────┐
										  					 │               │
									┌──────────────┘			 	       └─────────────┐
									│   ┌─┐┌─┐                                   │
									│		│●││●│                                   │
									│   └─┘└─┘	     													   │
									│		DL RST    ┌┐  ┌┐  ┌┐  ┌┐  ┌┐						 │
									│			        └┘  └┘  └┘  └┘  └┘						 │
									│			        ┌┐  ┌┐  ┌┐  ┌┐  ┌┐						 │
									│		┌───┐     └┘  └┘  └┘  └┘  └┘	    ┌───┐	 │
									│		│   │     ┌┐  ┌┐  ┌┐  ┌┐  ┌┐		  │   │  │
									│		└───┘     └┘  └┘  └┘  └┘  └┘	    └───┘  │
									│		BTN_A     ┌┐  ┌┐  ┌┐  ┌┐  ┌┐ 		  BTN_B  │
									│			        └┘  └┘  └┘  └┘  └┘						 │
									│			        ┌┐  ┌┐  ┌┐  ┌┐  ┌┐						 │
									│			        └┘  └┘  └┘  └┘  └┘						 │
									│			     																   │
									│┌────┐	  ┌────┐	  ┌────┐  	┌────┐   ┌────┐│
									├┤    ├┬┬┬┤    ├┬┬┬┬┤    ├┬┬┬┬┤    ├┬┬┬┤    ├┤
									││ 0  │││││ 1  ││││││ 2  ││││││ 3V │││││GND ││
									└┴────┴┴┴┴┴────┴┴┴┴┴┴────┴┴┴┴┴┴────┴┴┴┴┴────┴┘
PIN								3     4 6      8 10 12  13 15 3V  3V 20    GND
PIN                      5 7      9  11    14 16     19 GND


-------------------
--Common Function--
-------------------
Matrix LED:	P4、P6、P7、P10
BTN_A			: P5
BTN_B			: P11		


LCD_SCREEN ILI9341_TFT
#define TFT_RESET       8		//connect P8
#define TFT_DC          9		//connect P9
#define TFT_CS          SPI_SS	//connect P16
//TFT_SDI(MOSI)         15 			//connect P15
//TFT_SDO(MISO)         NULL 
//TFT_SCK               13			//connect P13
						
hub8735bit can mapping the I/O board "hub8735:bit_IO_B"
P0、P1、P2、P3、P8、P9、P12、P14、P15、P16、P19、P20
*/