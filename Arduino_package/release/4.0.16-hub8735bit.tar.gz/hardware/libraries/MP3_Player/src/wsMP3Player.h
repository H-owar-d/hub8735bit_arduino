/**
  * @Date: 2025/04/07
  * @Creator: Bob_Su
  */
#ifndef __WS_MP3_PLAYER_H__
#define __WS_MP3_PLAYER_H__

//Defintions --------------------------------------------------------------
#define MP3_PLAYER_OK                                       0
#define MP3_PLAYER_ERROR                                    1
#define MP3_PLAYER_BUSY                                     2
//Type Definitions --------------------------------------------------------
typedef enum{
    PLAYER_CONTROL_STOP = 0,
    PLAYER_CONTROL_START,
    PLAYER_CONTROL_CONTINUE,
    PLAYER_CONTROL_MAX,
}PlayerControl_Typedef;
//External Functions ------------------------------------------------------
/**
 * @brief Initialize MP3 Player
 * @param *complete_cb: Complete callback
 * @retval None
 */
extern void wsMP3Player_init(void (*complete_cb)(void));
/**
 * @brief Play mp3 file
 * @param *name: File name
 * @param size: File name size
 * @retval Result
 */
extern uint8_t wsMP3Player_playFile(uint8_t *name, uint32_t size);
/**
 * @brief Play mp3 file by raw data
 * @param *raw: Raw data buffer
 * @param size: Raw data buffer size
 * @param ctrl: Player control
 * @retval Result
 */
extern uint8_t wsMP3Player_playRaw(uint8_t *raw, uint32_t size, PlayerControl_Typedef ctrl);

#endif //__WS_MP3_PLAYER_H__