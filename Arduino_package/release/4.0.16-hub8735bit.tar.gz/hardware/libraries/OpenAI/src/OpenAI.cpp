/**
  * @Date: 2025/03/11
  * @Creator: Bob_Su
  */
#include "OpenAI.h"

#if 0
#ifdef __cplusplus
extern "C" {
#endif //__cplusplus

#ifdef __cplusplus
}
#endif //__cplusplus
#endif

File *OpenAI::tts_file;
File *OpenAI::stt_file = 0;

void OpenAI::textToSpeechGetDataCallback(unsigned char status, unsigned char *data, unsigned long size)
{
    /*if(tts_file)
    {
        tts_file.write(data, size);
    }*/
    //tts_file->write(data, size);
    //printf("[%s] status [%d] size[%d] ret[%d]\r\n", __func__, status, size, tts_file->write(data, size));
    tts_file->write(data, size);
    /*if(status == OPENAI_TTS_EVENT_END)
    {
        printf("[BOB] Close File\r\n");
        tts_file->close();
    }*/
    //printf("[%s]\r\n", tts_file);
}
void OpenAI::speechToTextReadDataCallback(unsigned char *data, unsigned long *size)
{
    if((data) && (size) && (*size) && stt_file)
    {
        if(stt_file)
        {
            *size = stt_file->read(data, *size);
        }
        else
        {
            *size = 0;
        }
    }

}

OpenAI::OpenAI(void)
{

}
void OpenAI::begin(char *api_key)
{
    wsOpenAI_init((uint8_t *)api_key);
}
/**
 * @brief Add system prompt
 * @param *prompt: System prompt
 * @retval Result
 */
uint16_t OpenAI::chatAddSystemPrompt(char *prompt)
{
    return wsOpenAI_addInstruction((uint8_t *)prompt);
}
/**
 * @brief Add new user message
 * @param *message: New user message
 * @retval Result
 */
uint16_t OpenAI::chatAddUserMessage(char *message)
{
    return wsOpenAI_addMessage(OPENAI_ROLE_USER, (uint8_t *)message);
}
/**
 * @brief Clear all user messages
 * @param None
 * @retval None
 */
void OpenAI::chatClearUserMessage(void)
{
    wsOpenAI_clrMessage();
}
/**
 * @brief Start chat generation
 * @param None
 * @retval Chat genertaion string
 */
char* OpenAI::chatCompletion(void)
{
    char *resp_msg = (char *)wsOopenAI_chatCompletion();
    wsOpenAI_addMessage(OPENAI_ROLE_ASSISTANT, (uint8_t *)resp_msg);
    return resp_msg;
}
/**
 * @brief Convert text to speech
 * @param &file: Speech file
 * @param *text: Input text
 * @retval Result
 */
unsigned short OpenAI::textToSpeech(File &file, char *text)
{
    return textToSpeech(file, OPENAI_TTS_VOICE_ALLOY, text);
}
/**
 * @brief Convert text to speech
 * @param &file: Speech file
 * @param voice: Speech voice
 * @param *text: Input text
 * @retval Result
 */
unsigned short OpenAI::textToSpeech(File &file, OpenAITTSVoice_Typedef voice, char *text)
{
    tts_file = (File *)&file;

    return wsOopenAI_textToSpeech(voice, (uint8_t *)text, textToSpeechGetDataCallback);
}
/**
 * @brief Convert speech to text
 * @param &file: Speech file
 * @retval Text
 */
char* OpenAI::speechToText(File &file)
{
    stt_file = (File *)&file;
    return (char *)wsOopenAI_speechToText((uint8_t *)"winstec.mp4", (uint32_t)stt_file->size(), speechToTextReadDataCallback);
}