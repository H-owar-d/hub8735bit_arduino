/**
  * @Date: 2025/03/11
  * @Creator: Bob_Su
  */
 #ifndef __WS_OPENAI_BLOCK_H__
 #define __WS_OPENAI_BLOCK_H__

#include <stdio.h>

 #define WS_OPENAI_OK                           0
 #define WS_OPENAI_ERR                          1
 #define WS_OPENAI_BUSY                         2
 #define WS_OPENAI_MESSAGE_FULL                 3

/*
 * @brief Configure maximum number of response choices
 */ 
#define RESPONSE_CHOICES_NUMBER_MAXIMUM         3
/*
 * @brief Maximum number of messages
 */
#define MESSAGE_NUMBER_MAXIMUM                  16
/*
 * @brief Maximum message buffer size 
 */
#define MESSAGE_BUFFER_MAXIMUM                  1024
/*
 * @brief Maximum token of chat completion
 */
#define CHAT_COMPLETION_MAXIMUM_TOKEN           (2 * 1024)
/*
 * @brief Maximum data length for receiving/sending audio data
 */
#define AUDIO_BUFFER_MAXIMUM                    1024
/*
 * @brief Configure maximum size of STT text
 */
#define TEXT_BUFFER_MAXIMUM                     1024
/*
 * @brief Configure maximum size of HTTP body buffer
 */
#define HTTP_BODY_BUFFER_MAXIMUM                128
//Type Definitions-----------------------------------------------------------------------------------------
typedef enum{
    OPENAI_CHAT_MODEL_GPT4O = 0,
    OPENAI_CHAT_MODEL_GPT4OMINI,
    OPENAI_CHAT_MODEL_GPT4,
    OPENAI_CHAT_MODEL_GPT35TURBO,
    OPENAI_CHAT_MODEL_MAX,
}OpenAIChatModel_Typedef;
typedef enum{
    OPENAI_SPEECH_MODEL_TTS1 = 0,
    OPENAI_SPEECH_MODEL_TTS1HD,
    OPENAI_SPEECH_MODEL_MAX,
}OpenAISpeechModel_Typedef;
typedef enum{
    OPENAI_ROLE_SYSTEM = 0,
    OPENAI_ROLE_USER,
    OPENAI_ROLE_ASSISTANT,
    OPENAI_ROLE_TOOL,
    OPENAI_ROLE_MAX,
}OpenAIRole_Typedef;
typedef enum{
    OPENAI_TTS_EVENT_END = 0,
    OPENAI_TTS_EVENT_CONTINUE,
    OPENAI_TTS_EVENT_START,
    OPENAI_TTS_EVENT_MAX,
}OpenAITTSEvent_Typedef;
typedef enum{
    OPENAI_TTS_VOICE_ALLOY = 0,
    OPENAI_TTS_VOICE_ECHO,
    OPENAI_TTS_VOICE_FABLE,
    OPENAI_TTS_VOICE_ONYX,
    OPENAI_TTS_VOICE_NOVA,
    OPENAI_TTS_VOICE_SHIMMER,
    OPENAI_TTS_VOICE_MAX,
}OpenAITTSVoice_Typedef;
//External Functions ------------------------------------------------------------------------
/**
 * @brief Initialize OpenAI
 * @param *api_key: OpenAI API key
 * @return None
 */
extern void wsOpenAI_init(uint8_t *api_key);
/**
 * @brief Add instruction
 * @param *content: Instruction content
 * @retval Result
 */
extern uint32_t wsOpenAI_addInstruction(uint8_t *content);
/**
 * @brief Add message
 * @param role: Message's role
 * @param *content: Message content
 * @retval Result
 */
extern uint32_t wsOpenAI_addMessage(OpenAIRole_Typedef role, uint8_t *content);
/**
 * @brief Clear message
 * @param None
 * @retval Result
 */
extern uint32_t wsOpenAI_clrMessage(void);
/**
 * @brief Chat with GPT
 * @param None
 * @retval Result
 */
extern uint8_t *wsOopenAI_chatCompletion(void);
/**
 * @brief Convert text to speech
 * @param voice: Speech voice
 * @param *text: Input text
 * @param *callback: Get data callback
 * @retval Result (0:Success Others:Failed)
 */
extern uint32_t wsOopenAI_textToSpeech(OpenAITTSVoice_Typedef voice, uint8_t *text, void (*callback)(uint8_t, uint8_t *, uint32_t));
/**
 * @brief Convert speech to text
 * @param *f_name: File Name
 * @param f_size: File Size
 * @param *callback: Read data callback
 * @retval Text
 */
extern uint8_t *wsOopenAI_speechToText(uint8_t *f_name, uint32_t f_size, void (*callback)(uint8_t *, uint32_t*));
#endif //__WS_OPENAI_BLOCK_H__